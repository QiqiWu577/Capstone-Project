create
  definer = root@localhost procedure set_password(IN empider int, IN hasher varchar(400), IN salter varchar(400))
BEGIN
  IF EXISTS (select * from salt where emp_id = empider) THEN
    update salt set hash = hasher, salt = salterlt where emp_id=empider;
  ELSE
    insert into salt values (empider, hasher, salter);
  END IF;
END;

