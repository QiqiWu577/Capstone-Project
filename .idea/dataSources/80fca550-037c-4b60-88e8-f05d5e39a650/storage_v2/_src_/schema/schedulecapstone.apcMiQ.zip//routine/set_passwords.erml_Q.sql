create procedure set_passwords(IN empider int, IN hasher varchar(200), IN salter varchar(200))
BEGIN


  IF EXISTS (select * from salt where emp_id = empider) THEN
    update salt set salt = salter where emp_id = empider;
    update salt set hash = hasher where emp_id = empider;
  ELSE
    insert into salt values (empider, hasher, salter);
  END IF;


END;

