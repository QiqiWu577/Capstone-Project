create procedure get_login(IN empid int)
BEGIN
  SELECT hash, salt from salt where emp_id = empid;
END;

