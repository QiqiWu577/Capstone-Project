create
  definer = root@localhost procedure get_login(IN emp_id int)
BEGIN
  SELECT hash, salt
  FROM salt
  WHERE emp_id = emp_id;
END;

